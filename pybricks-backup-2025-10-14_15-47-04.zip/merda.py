from func import *

def merda ():

    moveToLight(10, 30, 0, 2.5)
    moveToDistance(3, 60, 0, 2.5)

merda ()